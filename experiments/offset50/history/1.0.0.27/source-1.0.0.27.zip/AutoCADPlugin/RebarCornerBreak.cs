using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.Geometry;

namespace AutoCADPlugin;

// Identify concavity on the closed material inset, never on an anchored open
// path: an anchorage elbow is not a material corner.
internal static class RebarCornerBreak
{
    public const double ExtensionLength = 400;
    private const double NumericTolerance = 1e-6;

    internal sealed class Result
    {
        public List<RebarPath> Bars { get; } = new List<RebarPath>();
        public List<RebarExtensionCollision.Extension> Ends { get; } = new List<RebarExtensionCollision.Extension>();
        public int CornerCount { get; set; }
    }

    private sealed class Corner
    {
        public Corner(Point2d point, Vector2d incoming, Vector2d outgoing)
        { Point = point; Incoming = incoming; Outgoing = outgoing; }
        public Point2d Point { get; }
        public Vector2d Incoming { get; }
        public Vector2d Outgoing { get; }
    }

    private sealed class Piece
    {
        public Piece(RebarPath path, RebarExtensionCollision.Extension? start, RebarExtensionCollision.Extension? end)
        { Path = path; Start = start; End = end; }
        public RebarPath Path { get; }
        public RebarExtensionCollision.Extension? Start { get; }
        public RebarExtensionCollision.Extension? End { get; }
    }

    public static Result Apply(IReadOnlyList<RebarPath> anchoredBars, IReadOnlyList<List<Point2d>> insetLoops)
    {
        var result = new Result();
        var corners = FindCorners(insetLoops);
        var pieces = new List<Piece>();
        for (var pathIndex = 0; pathIndex < anchoredBars.Count; pathIndex++)
        {
            var path = anchoredBars[pathIndex];
            var cuts = new List<int>();
            for (var i = path.IsClosed ? 0 : 1; i < path.Points.Count - (path.IsClosed ? 0 : 1); i++)
            {
                if (corners.Any(corner => Matches(path, i, corner))) { cuts.Add(i); }
            }
            result.CornerCount += cuts.Count;
            Split(path, pathIndex, cuts, pieces, result.Ends);
        }
        RebarExtensionCollision.Trim(result.Ends, anchoredBars);
        foreach (var piece in pieces)
        {
            if (piece.Start is null && piece.End is null) { result.Bars.Add(piece.Path); continue; }
            var points = new List<Point2d>();
            if (piece.Start is not null && piece.Start.Length > NumericTolerance) { points.Add(piece.Start.Tip); }
            points.AddRange(piece.Path.Points);
            if (piece.End is not null && piece.End.Length > NumericTolerance) { points.Add(piece.End.Tip); }
            result.Bars.Add(new RebarPath(points, false));
        }
        return result;
    }

    private static List<Corner> FindCorners(IReadOnlyList<List<Point2d>> loops)
    {
        var result = new List<Corner>();
        foreach (var loop in loops)
        {
            var winding = Math.Sign(ContourGraph.Area(loop));
            for (var i = 0; i < loop.Count; i++)
            {
                var incoming = loop[i] - loop[(i + loop.Count - 1) % loop.Count];
                var outgoing = loop[(i + 1) % loop.Count] - loop[i];
                if (incoming.Length <= ContourGraph.Tolerance || outgoing.Length <= ContourGraph.Tolerance) { continue; }
                var a = incoming.GetNormal();
                var b = outgoing.GetNormal();
                // Right angles accept only drawing noise within the existing
                // 0.1 distance tolerance, capped at 0.001 radians for short edges.
                var angularTolerance = Math.Min(.001, ContourGraph.Tolerance / Math.Min(incoming.Length, outgoing.Length));
                if (Math.Abs(a.DotProduct(b)) > angularTolerance || Cross(a, b) * winding >= 0) { continue; }
                result.Add(new Corner(loop[i], a, b));
            }
        }
        return result;
    }

    private static bool Matches(RebarPath path, int index, Corner corner)
    {
        var point = path.Points[index];
        if (point.GetDistanceTo(corner.Point) > ContourGraph.Tolerance) { return false; }
        var a = point - path.Points[(index + path.Points.Count - 1) % path.Points.Count];
        var b = path.Points[(index + 1) % path.Points.Count] - point;
        if (a.Length <= NumericTolerance || b.Length <= NumericTolerance) { return false; }
        a = a.GetNormal(); b = b.GetNormal();
        // Support opening / native offsets can reverse the traversal direction.
        return (a.DotProduct(corner.Incoming) > .999999 && b.DotProduct(corner.Outgoing) > .999999) ||
            (a.DotProduct(-corner.Outgoing) > .999999 && b.DotProduct(-corner.Incoming) > .999999);
    }

    private static void Split(RebarPath path, int pathIndex, List<int> cuts,
        List<Piece> pieces, List<RebarExtensionCollision.Extension> ends)
    {
        if (cuts.Count == 0) { pieces.Add(new Piece(path, null, null)); return; }
        var boundaries = path.IsClosed ? cuts : new[] { 0 }.Concat(cuts).Concat(new[] { path.Points.Count - 1 }).ToList();
        var pieceCount = path.IsClosed ? boundaries.Count : boundaries.Count - 1;
        for (var i = 0; i < pieceCount; i++)
        {
            var startIndex = boundaries[i];
            var endIndex = boundaries[(i + 1) % boundaries.Count];
            var points = new List<Point2d> { path.Points[startIndex] };
            var current = startIndex;
            do
            {
                current = (current + 1) % path.Points.Count;
                points.Add(path.Points[current]);
            } while (current != endIndex);
            var start = path.IsClosed || i > 0 ? MakeEnd(startIndex, points[1]) : null;
            var end = path.IsClosed || i < pieceCount - 1 ? MakeEnd(endIndex, points[points.Count - 2]) : null;
            pieces.Add(new Piece(new RebarPath(points, false), start, end));
        }

        RebarExtensionCollision.Extension MakeEnd(int vertex, Point2d neighbor)
        {
            var point = path.Points[vertex];
            var end = new RebarExtensionCollision.Extension(point, (point - neighbor).GetNormal(),
                ExtensionLength, pathIndex, vertex);
            ends.Add(end);
            return end;
        }
    }

    private static double Cross(Vector2d a, Vector2d b) => a.X * b.Y - a.Y * b.X;
}
